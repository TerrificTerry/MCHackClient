var scriptName = "ExhibitionSpeedMine";
var scriptVersion = 1.0;
var scriptAuthor = "Bury";

var SpeedMine = new SpeedMine();
var client;
var Potion = Java.type('net.minecraft.potion.Potion');
var PotionEffect = Java.type('net.minecraft.potion.PotionEffect');
var ItemPickaxe = Java.type('net.minecraft.item.ItemPickaxe');
function SpeedMine() {
	var Level = value.createInteger("Level",1,0,10);
    this.getName = function() {
        return "SpeedMine";
    };

    this.getDescription = function() {
        return "SpeedMine";
    };

    this.getCategory = function() {
        return "Misc";
    };
	this.addValues = function(event) {
		event.add(Level);
	}
	this.onUpdate = function() {
		if(Level.get() != 0) {
			mc.playerController.blockHitDelay = 0;
			mc.thePlayer.addPotionEffect(new PotionEffect(Potion.digSpeed.getId(), 100, (Level.get()-1)));
		} else if(Level.get() == 0) {
			mc.playerController.blockHitDelay = 0;
			mc.thePlayer.addPotionEffect(new PotionEffect(Potion.digSpeed.getId(), 100, Level.get())));
		}
	}
	this.onDisable = function() {
		mc.thePlayer.removePotionEffect(Potion.digSpeed.getId());
	}
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(SpeedMine);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}