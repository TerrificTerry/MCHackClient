var script = registerScript({
    name: "LongJumpAlpha",
    version: "1.0",
    authors: ["Messenger"]
});

var S08PacketPlayerPosLook = Java.type('net.minecraft.network.play.server.S08PacketPlayerPosLook');
var air;

script.registerModule({
    name: "LongJumpAlpha",
    description: "HytNew",
    description: "Longjump",
    category: "Combat",
    settings: {
        dis: Setting.boolean({
            name: "lagbackground",
            default: true
        })
    }
}, function(module) {
    module.on("enable", function() {
        air = 0;
    });

    module.on("disable", function() {

    });

    module.on("packet", function(event) {
        var packet = event.getPacket();
        if (packet instanceof S08PacketPlayerPosLook) {
            moduleManager.getModule("LongJumpAlpha").setState(false);
        }
    });

    module.on("move", function(event) {

    });

    module.on("update", function() {
        if (!mc.thePlayer.onGround) {
            air++;
        } else if (air > 3 && module.settings.dis.get()) {
            moduleManager.getModule("LongJumpAlpha").setState(false);
        }
        if (mc.thePlayer.onGround && (!module.settings.dis.get() || air == 0)) {
            mc.thePlayer.jump();
        }
        mc.thePlayer.jumpMovementFactor = 0.05009190001;
        mc.thePlayer.motionY += 0.0303;
    });
});