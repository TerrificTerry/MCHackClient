﻿var scriptName = '1'
var scriptAuthor = '1'
var scriptVersion = 1.0
var scripeMoudleName = "KanaeAutoGame"


function a() {


	this.getName = function () {
		return scripeMoudleName
	}

	this.getDescription = function () {
		return 'JS'
	}

	this.getCategory = function () {
		return 'Fun'
	}
	this.onUpdate = function () {

moduleManager.getModule(scripeMoudleName).setState(false)
	}
	    this.onEnable = function() {
mc.thePlayer.sendChatMessage("/game bw-team")
moduleManager.getModule(scripeMoudleName).setState(false)
	}
}

var a = new a()
var b

function onEnable() {
	b = moduleManager.registerModule(a)
}

function onDisable() {
	moduleManager.unregisterModule(b)
}