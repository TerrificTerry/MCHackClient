var scriptName = "AirBounce";
var scriptVersion = 1.1;
var scriptAuthor = "暗狼"
var BlinkModule = moduleManager.getModule("Blink");
var AirBounce = new AirBounce();
var client;


function AirBounce() {
	var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils')
	var ArrayList = Java.type('java.util.ArrayList');
	var LinkedList = Java.type('java.util.LinkedList');
	var MotionF = value.createFloat("CustomMotionSpike", 5, 1, 100);
	var MotionY = value.createFloat("CustomMotionY", 5, 1, 30);
	
    this.getName = function() {
        return "AirBounce";
    };
    this.getDescription = function() {
        return "AirBounce";
    };
    this.getCategory = function() {
        return "Movement";
    };
    this.onEnable = function() {
		BlinkModule.setState(true);
				                               mc.thePlayer.motionY = MotionY.get();
		                               mc.thePlayer.motionX *= MotionF.get();
									   		                               mc.thePlayer.motionZ *= MotionF.get();
    };
    this.onDisable = function() {
		BlinkModule.setState(false);
    }
		this.addValues = function(values) {
		values.add(MotionF);
		values.add(MotionY);
    };
	this.onUpdate = function() {
        	if(mc.thePlayer.onGround || isOnGround(0.5))
				mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        	if(mc.thePlayer.isBlocking() && MovementUtil.isMoving() && isOnGround(0.42) && ( Aura.curTarget == null)){
    			if(timer.delay(65)){	
    				mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
    				timer.reset();
				}
			}
				
	};
}

function onLoad() {}

function onEnable() {
   client = moduleManager.registerModule(AirBounce)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}