var scriptName = "NewCriticals"; 
var scriptVersion = 9.0; 
var scriptAuthor = "LaoTong";

var Blink = moduleManager.getModule("Blink");
var NewCriticals = new NewCriticals(); 
var NewCriticzlsClient;


function NewCriticals() {
	var Mode = value.createList("Mode", ["Jump","Hypixel","BlinkFix","Blink","NewBlink","Blink2","LowHop","TimerHop"], "Blink2");

    this.getName = function() {
        return "NewCriticals";
    };

    this.getDescription = function() {
        return "NewCriticals.";
    };

    this.getCategory = function() {
        return "Fun";
    };
	this.getTag = function() {
        return Mode.get(); 
    };
    this.onAttack = function (event) {
		target = event.getTargetEntity();
		if(mc.thePlayer.onGround) {
		switch(Mode.get()) {
		case "Jump":
		mc.thePlayer.motionY = 0.35;
		break;
		case "BlinkFix":
		Blink.setState(true)
		mc.thePlayer.motionY = 0.114514;
		mc.thePlayer.motionX =0.00025114514;
		Blink.setState
		case "Hypixel":
		Blink.setState(true)
		mc.thePlayer.motionY = 0.05;
		Blink.setState(false)
		case "Blink":
		Blink.setState(true)
		mc.thePlayer.motionY = 0.114514;
		mc.timer.timerSpeed = 1.17;
		Blink.setState(false)
		break;
		case "Blink2":
		Blink.setState(true)
		mc.thePlayer.motionY = 0.25;
		mc.timer.timerSpeed = 1.17;
		Blink.setState(false)
		break;
		case "NewBlink":
		Blink.setState(true)
		mc.thePlayer.motionY = 0.133333333333333333333333333333333333333;
		Blink.setState(false)
		break;
		case "LowHop"://孤傲的浮点
		mc.thePlayer.motionY = 0.12451415;
		mc.timer.timerSpeed = 0.8848;
		break;
		case "TimerHop":
		mc.thePlayer.motionY = 0.3;
		mc.timer.timerSpeed = 1.17;
		break;
		}
		}
	}
	this.onDisable = function() {
		mc.timer.timerSpeed = 1;
	}
	this.onPacket = function(event) {
		if(Mode.get() == "NoGround") {
		var packet = event.getPacket();
		if(packet instanceof C03PacketPlayer) {
			packet.onGround = false;
		}
		}
	}
	this.addValues = function(values) {
		values.add(Mode);

    }
}

function onLoad() {
};

function onEnable() {
    NewCriticalsClient = moduleManager.registerModule(NewCriticals);
};

function onDisable() {
    moduleManager.unregisterModule(NewCriticalsClient);
};