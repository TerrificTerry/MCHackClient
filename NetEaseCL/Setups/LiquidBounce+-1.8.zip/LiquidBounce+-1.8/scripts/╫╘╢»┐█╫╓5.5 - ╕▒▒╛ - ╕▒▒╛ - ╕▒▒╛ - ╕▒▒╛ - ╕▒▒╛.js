var scriptName = "自动扣字";
var scriptVersion = 5.4;
var scriptAuthor = "华为给你增智慧";

var Random = Java.type('java.util.Random');
var Display = Java.type('org.lwjgl.opengl.Display')

var Debug = new Debug();
var client;

function Debug() {
	var HM,QQ;
	var random = new Random();
    var a = random.nextInt(21);
    this.getName = function() {	
        return "AutoCurse6";
    };

    this.getDescription = function() {
        return "华为给你增智慧";
    };

    this.getCategory = function() {
        return "LThings";
    };
    this.onEnable = function() {
		HM = 0;
		QQ = -1;
    }
    this.onUpdate = function() {
		HM += 1;
        a = random.nextInt(76);
        if (HM == 30){
			HM = 0;
        if (QQ > -1){
            QQ += 1
        if (QQ >= 11){
            QQ = -1
        }
        }
        if (QQ == -1){
		    switch (a){
			case 0:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你怎么就是喜欢一个劲的在这造谣爸爸我啊");
                break;
            case 1:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 穷小子你是不是开始恼羞成怒狗急跳墙了啊");
                break;
            case 2:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你就是死皮赖脸的小伙子是不是啊");
                break;
            case 3:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 小伙子你就是个缩头乌龟啊我知道的啊");
                break;
			case 4:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你看看你现在是不是已经面红耳赤了啊");
                break;
			case 5:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你现在能不能够快马加鞭的滚出来反抗爷爷我啊");
                break;
			case 6:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你为什么喜欢和你大爹我说三道四的呢");
                break;
			case 7:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你就是野爹我的手下败将啊知不知道呢");
                break;
			case 8:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你为什么总是爱幻想着打败神爹我呢 你明明清楚这是永远也不可能的啊");
                break;
			case 9:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 知道不知道你自己就是个耀武扬威不三不四的窝囊废啊");
                break;
			case 10:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 我操你妈的你不就是个垃圾狗篮子吗 你到底拿什么和你爸爸我抗衡啊");
                break;
			case 11:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 告诉大家是不是啊你为什么一声不吭了你这条逃逸狗啊");
                break;
			case 12:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你这个半身不遂的窝囊废为什么就是喜欢一直东躲西藏呢");
                break;
			case 13:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 爷爷我现在拿起一把大砍刀腾空一跃就把你穷婊子妈碎尸万段了呢");
                break;
			case 14:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你怎么好像开始力不从心了呢 爷爷我现在是不是能够随便羞辱你臭婊子妈了啊");
                break;
			case 15:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 我操你妈的还大言不惭吹逼是不是啊 能不能够加快速度反抗我啊");
                break;
			case 16:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 垃圾狗篮子你在干什么啊 跟上你爸爸的节奏行不行啊");
                break;
			case 17:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 我操你妈的你现在怎么开始沉默不语了呢");
                break;
			case 18:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 我操你妈的你这个窝囊废为什么就是躲躲藏藏不敢滚出来直面神爹我了呢");
                break;
			case 19:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你为什么就是不敢承认你这个窝囊废的事实呢穷小子");
                break;
			case 20:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你告诉我你爸爸是不是开拖拉机的啊小子");
                break;
			case 21:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你自己就是个穷酸蛤蟆啊我操你妈的半身不遂的垃圾狗篮子啊");
                break;
			case 22:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 我操你妈的你就是个忤逆不孝的畜生啊");
                break;
			case 23:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 穷小子是不是啊你告诉我呢成天在这里刷屏你是不是条疯狗啊");
                break;
			case 24:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你个耀武扬威的穷酸土狗为什么就是不清楚你自己是个什么东西呢");
                break;
			case 25:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 是不是回答我啊你在絮絮叨叨什么东西啊臭蛤蟆");
                break;
			case 26:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你干什么啊狗篮子你是不是妄图提高你的速度了啊");
                break;
			case 27:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你现在是不是已经躲在墙角默默擦眼泪了呢孩子");
                break;
			case 28:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你是不是感觉自己开始无能为力了 没有速度汗流浃背啊");
                break;
			case 29:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你是不是知道你自己要输给你登峰造极的爸爸我了啊是不是啊");
                break;
			case 30:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你开始不是风风火火的速度么 现在怎么不敢吭声了我操你妈了个大臭逼啊");
                break;
			case 31:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你现在怎么三三两两的言语了啊 你是不是对你大爹的教导无能为力了呢");
                break;
			case 32:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你干什么啊小伙子 你是不是窝囊废啊我操你妈的啊告诉我行不行啊");
                break;
			case 33:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你这条野狗为什么就是喜欢乱咬人呢爷爷我就是喜欢开纪殴打你啊");
                break;
			case 34:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你还大言不惭的吹嘘你的扣字速度是不是啊");
                break;
			case 35:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你一五一十的告诉爸爸我行不行啊小伙子 你为什么好像就是无言以对了呢");
                break;
			case 36:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你是不是悬心吊胆的以为你可以赢过你登峰造极的爸爸我啊");
                break;
			case 37:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你是不是觉得你可以了告诉我行不行啊你用什么殴打你爸爸我啊");
                break;
			case 37:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你是不是觉得你可以了啊告诉我行不行啊死皮赖脸的告诉我你在干什么");
                break;
			case 38:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你就是个一无是处的窝囊废啊操你妈的知道不知道啊 是不是畏惧你大爹我了");
                break;
			case 39:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你现在怎么默不作声了是不是已经词穷了啊");
                break;
			case 40:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你好像就是完完全全没有文化水平啊 ");
                break;
			case 41:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你看看野爹我现在是不是能够随随便便暴打你这个穷酸废蛆啊");
                break;
			case 42:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 酒囊饭袋一样的窝囊废是不是啊");
                break;
			case 43:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你看看你的残疾速度怎么敢拿出来在你大爹我面前丢人现眼啊");
                break;
			case 44:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你这个支离破碎的垃圾词汇怎么好意思拿出来在野爹我面前光宗耀祖啊");
                break;
			case 45:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你难道还不清楚你就是个喜欢丢人现眼的癞蛤蟆吗");
                break;
			case 46:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你现在为什么开始视而不见了你还不明白自己就是个彻头彻尾的窝囊废么");
                break;
			case 47:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你现在就是畏惧你大爹我了啊完全殴打你是不是这样啊");
                break;
			case 48:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你这条野狗现在是不是狂犬病发作了啊 能不能回狗笼子里好好待着啊");
                break;
			case 49:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你以为你这个毫无杀伤力的破烂词汇能够与你神爹我抗衡么");
                break;
			case 50:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你看看你自己到底和个穷酸骡子有什么区别呢");
                break;
            case 51:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你到底在跟我诉说什么呢孩子 你那三言两语的词汇和个螃蟹有什么区别啊");
                break;
            case 52:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 爷爷我殴打你这条穷狗不是简简单单轻轻松松么");
                break;
            case 53:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你怎么好像还是接受不了这个亲娘惨死的现实啊");
                break;
            case 54:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你这个没有速度的残疾人为什么就是喜欢造谣野爹我开软件啊");
                break;
            case 55:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你自己永生永世就是个窝囊废啊 能不能够把你的臭嘴给你爷爷我闭上啊");
                break;
            case 56:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你好像完完全全没有实力与你神爹我抗衡啊 可是你为什么还是这么的坚持不懈呢");
                break;
            case 57:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你为什么这么的语无伦次没有一点思维逻辑啊 你告诉我你是不是只乌龟啊");
                break;
            case 58:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 狗篮子说句话啊 你现在是不是已经开始惶恐不安不知所措了啊");
                break;
            case 59:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 我操你妈的你这个落荒而逃的窝囊废啊 你为什么这么的丢人现眼啊");
                break;
            case 60:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你这条疯狗怎么就是喜欢一个劲的狂吠啊 爷爷我待会儿就让你老妈子把你拴起来打一顿呢");
                break;
            case 61:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你现在是不是已经泪流满面了呢告诉爷爷我啊");
                break;
            case 62:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你到底在鬼哭狼嚎什么东西啊 你婊子妈的死亡就是个永远都无法改变的惨痛事实啊");
                break;
            case 63:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你看看你自己现在是不是被爷爷我暴打得满地找牙啊 你这条死要面子的土狗还不肯承认自己窝囊废的事实啊");
                break;
            case 64:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 我知道你那幼小的心灵早已经承受不住野爹我对你沉重的打击了呢");
                break;
            case 65:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你告诉爸爸我你现在是不是坐在电脑前看着你野爹我登峰造极的言语却无能为力默默哭泣呢孩子");
                break;
            case 66:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你现在能不能给你祖师爷我跪下磕头认错啊 你这个死皮赖脸的本性怎么就是改不掉呢");
                break;
            case 67:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你怎么又开始意淫爷爷我复制粘贴了啊 你自己这个蜗牛似的没有速度啊");
                break;
            case 68:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你告诉我你是不是个龟头少年啊 你为什么畏惧我了无能逃逸啊");
                break;
            case 69:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你这个缩头乌龟似的窝囊废爸爸我看不起你啊 你现在能不能够拿出你的速度来与我抗衡啊");
                break;
            case 70:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你现在是不是只能够忍气吞声啊 为你自己的言行举止感到羞耻啊");
                break;
            case 71:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 我操你妈的你看看你自己那副疯狂敲击箭头发送的穷酸样是不是像极了一条哈巴狗啊");
                break;
            case 72:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你这个大逆不道的龟孙为什么就是喜欢这个无能射箭呢 你在耀武扬威你穷婊子妈的大臭逼啊");
                break;
            case 73:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 爷爷我现在宣布弓箭狗就是死爹烂妈的孤儿啊 你应该没有什么意见吧");
                break;
            case 74:
                mc.thePlayer.sendChatMessage("/friends m TFTAOFENGEGE 你能不能滚出来解释一下子你为什么无能嗑药啊 是不是终于明白自己是个无能为力的窝囊废了啊");
                break;
            default:
        }
        }
        }
	}
    this.onDisable = function () {	
	}
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Debug);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}