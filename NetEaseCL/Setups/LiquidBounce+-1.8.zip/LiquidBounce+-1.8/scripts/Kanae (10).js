﻿var scriptName = "title";
var scriptVersion = 1.0;
var scriptAuthor = "AquaVit、FunkNight";
//Frances修改
var Random = Java.type('java.util.Random');
var Display = Java.type('org.lwjgl.opengl.Display')

var Debug = new Debug();
var client;

function Debug() {
	var HM,H,M,S;
	var random = new Random();
    var a = random.nextInt(25); 
    this.getName = function() {
        return "Title & AntiNC ";
    };

    this.getDescription = function() {
        return "VlxeBounce";
    };

    this.getCategory = function() {
        return "Fun";
    };
	
	this.getTag = function() {
		return "Timer";
	}
    this.onEnable = function() {
		HM = 0;
		H = 0;
		M = 0;
		S = 0;
    }
    this.onUpdate = function() {
		HM += 1;
        if (HM == 20){
			S = S + 1;
			HM = 0;
		}
        if (S == 60){
		    M = M + 1;
			S = 0;
		}
        if (M == 60){
            H = H + 1;
			M = 0;
		}			
		switch (a){
			case 1:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 您已游玩 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 2:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流逝 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 3:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 4:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 5:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 6:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 7:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失'+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 8:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失'+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 9:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失'+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 10:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 11:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 12:
                Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
                break;
	case 13:
	Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		break;
		case 14:
		    Display.setTitle("KKanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 15:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 16:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 17:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 18:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 19:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 20:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 21:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 22:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 23:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
		case 24:
		    Display.setTitle("Kanae|“樱花落下的速度是每秒五米，我该用怎么样的速度，才能与你相遇”|公益群号:815083671|"+ ' 时间已流失 '+ H  +'时'  +M +'分'+S+'秒');
		    break;
            default:
        }
	}
    this.onDisable = function () {	
	}
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Debug);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}
