/// api_version=2
var script = registerScript({
    name: "AAC5TimerHop",
    version: "1.0",
    authors: ["3Ws"]
});
var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils');
script.registerModule({
    name: "AAC5TimerHop",
    description: "SPEEEEEED IN REDESKY & other server w/ AAC5 AntiCheat",
    category: "Movement",
    settings: {
	}
}, function (module) {
	module.on("enable", function () {
		mc.timer.timerSpeed = 1.010001;
    });
	module.on("disable", function () {
		mc.timer.timerSpeed = 1.0;
    });
	module.on("update", function () {
		if (mc.thePlayer.onGround && MovementUtils.isMoving()) {
			mc.thePlayer.jump();
		};
	});
});