﻿var S12PacketEntityVelocity = Java.type("net.minecraft.network.play.server.S12PacketEntityVelocity");
var array = {
	name: "Antivelocity",
	version: "1.0.0",
	authors: ["Messenger"]
};
var script = registerScript(array);
var objectArray = {};
objectArray.name = "Antivelocity",
objectArray.category = "Combat",
objectArray.description = "Antivelocity",
objectArray.tag = "HuaYuTing",
script.registerModule(objectArray,
function(module) {
	module.on("packet",
	function(event) {
		var packet = event.getPacket();
		if (0 < mc.thePlayer.hurtTime) {
			if (packet instanceof S12PacketEntityVelocity) {
				packet.y += 0.11451419198
			}
			if (packet instanceof S12PacketEntityVelocity) {
				
				packet.motionX = 0 * packet.getMotionX();
				packet.motionY = 0 * packet.getMotionY();
				packet.motionZ = 0 * packet.getMotionZ()
			}
		} else {
			if (packet instanceof S12PacketEntityVelocity) {
				packet.motionX = 0 * packet.getMotionX();
				packet.motionY = 0 * packet.getMotionY();
				packet.motionZ = 0 * packet.getMotionZ()
			}
			if (packet instanceof S12PacketEntityVelocity) {
				packet.y += 0.11451419198
			}
		}
	})
});