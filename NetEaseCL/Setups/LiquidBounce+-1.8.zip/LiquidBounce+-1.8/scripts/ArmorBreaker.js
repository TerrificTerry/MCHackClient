﻿var scriptName = "ArmorBreaker"; 
var scriptVersion = 1.1;
var scriptAuthor = "fu917";
var cri = new Cri();
var cl;
function Cri() {
	var ticks = 0;
	this.getName = function() {
		return "ArmorBreaker";
	};
	this.getDescription = function() {
		return "ArmorBreaker";
	};
	this.getCategory = function() {
		return "Fun";
	};
	this.onEnable = function() {
		chat.print("§4§娱乐粒子包lol 真正的穿甲是不存在的 圈钱神你妈不得好死 Byfu917");
	};
	this.onAttack = function(event) {
		var Target = event.getTargetEntity();
		if(mc.thePlayer.onGround) {
			mc.thePlayer.onCriticalHit(Target);
			};
	};
	this.onDisable = function() {
		chat.print("§4§娱乐粒子包lol 真正的穿甲是不存在的 圈钱神你妈不得好死 Byfu917");
		ticks = 0;
	};		
};
function onLoad() {
};

function onEnable() {
    cl = moduleManager.registerModule(cri);
};

function onDisable() {
    moduleManager.unregisterModule(cl);
};