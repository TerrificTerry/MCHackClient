/// api_version=2
var script = registerScript({
    name: "Ababababds",
    version: "1.1",
    authors: ["Co丶Dynamic"]
});
var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils');
var RandomUtils=Java.type('net.ccbluex.liquidbounce.utils.misc.RandomUtils');
var S12PacketEntityVelocity = Java.type('net.minecraft.network.play.server.S12PacketEntityVelocity');
var Switcher;
var ticks;
script.registerModule({
    name: "AAC4Speed",
    description: "Co丶Dynamic",
    category: "Movement",
    settings: {
		Mode: Setting.list({
            name: "Mode",
            default: "AAC4Default",
            values: ["AAC4Default","AAC4LowHop","OldRedeskyLow","OldRedeskyFast","YPort"]
        })
	}
}, function (module) {
	module.on("enable", function () {
		ticks=0;
	});
	module.on("update", function () {
		if(!(mc.thePlayer.isInWater() || mc.thePlayer.isInLava() || mc.thePlayer.isOnLadder() || mc.thePlayer.isRiding() || mc.thePlayer.isInWeb) && !mc.thePlayer.onGround) {
			if(mc.thePlayer.motionY>0) {
				mc.thePlayer.motionY = mc.thePlayer.motionY/0.9800000190734863;
				switch(module.settings.Mode.get()) {
					case "AAC4Default":
						mc.timer.timerSpeed =1.45;
						mc.thePlayer.jumpMovementFactor=0.02;
						break;
					case "AAC4LowHop":
						mc.timer.timerSpeed =0.6;
						mc.thePlayer.motionY -= 0.025;
						mc.thePlayer.jumpMovementFactor=0.032;
						break;
					case "OldRedeskyLow":
						mc.timer.timerSpeed =1.04;
						mc.thePlayer.motionY -= 0.03;
						mc.thePlayer.jumpMovementFactor=0.0375;
						break;
					case "OldRedeskyFast":
						mc.timer.timerSpeed =1.04;
						mc.thePlayer.motionY -= 0.03;
						mc.thePlayer.jumpMovementFactor=0.0375;
						ticks=0;
						break;
					case "YPort":
						mc.timer.timerSpeed =0.9;
						mc.thePlayer.motionY -= 0.001;
						mc.thePlayer.jumpMovementFactor=0.0201;
						break;
				};
				mc.thePlayer.motionY *= 0.9800000190734863;
			}else{
				mc.thePlayer.motionY = mc.thePlayer.motionY/0.9800000190734863;
				switch(module.settings.Mode.get()) {
					case "AAC4Default":
						mc.timer.timerSpeed =0.65;
						mc.thePlayer.jumpMovementFactor=0.0205;
						break;
					case "AAC4LowHop":
						mc.timer.timerSpeed =0.8;
						mc.thePlayer.motionY -= 0.000;
						mc.thePlayer.jumpMovementFactor=0.02;
						break;
					case "OldRedeskyLow":
						mc.timer.timerSpeed =0.98;
						mc.thePlayer.motionY += 0.015;
						mc.thePlayer.jumpMovementFactor=0.037;
						break;
					case "OldRedeskyFast":
						ticks++;
						mc.timer.timerSpeed =1.00;
						mc.thePlayer.motionY -= 0.01;
						mc.thePlayer.jumpMovementFactor=0.0375;
						if(ticks==2 || ticks==3) {
							mc.thePlayer.jumpMovementFactor=0.14;
						};
						break;
					case "YPort":
						if(mc.thePlayer.fallDistance>0.7 && mc.thePlayer.fallDistance<1.7) {
							mc.timer.timerSpeed =4.00;
							mc.thePlayer.motionY -= 0.03;
							mc.thePlayer.jumpMovementFactor=0.0205;
						}else if(mc.thePlayer.fallDistance>1.7) {
							mc.timer.timerSpeed =1.0;
						};
						break;
				};
				mc.thePlayer.motionY *= 0.9800000190734863;
			};
		};
		if(mc.thePlayer.onGround) mc.timer.timerSpeed =1.0;
		if(mc.thePlayer.onGround && MovementUtils.isMoving()) {
			mc.thePlayer.jump();
			switch(module.settings.Mode.get()) {
				case "AAC4Default":
					mc.timer.timerSpeed =1.0;
					mc.thePlayer.jumpMovementFactor=0.02;
					break;
				case "AAC4LowHop":
					mc.timer.timerSpeed =0.7;
					mc.thePlayer.motionY = 0.40;
					mc.thePlayer.jumpMovementFactor=0.02;
					break;
				case "OldRedeskyLow":
					mc.timer.timerSpeed =0.98;
					mc.thePlayer.motionY = 0.3875;
					mc.thePlayer.jumpMovementFactor=0.0225;
					break;
				case "OldRedeskyFast":
					mc.timer.timerSpeed =0.98;
					mc.thePlayer.motionY = 0.3875;
					mc.thePlayer.jumpMovementFactor=0.0225;
					ticks=0;
					break;
				case "YPort":
					mc.timer.timerSpeed =1.2;
					mc.thePlayer.motionY = 0.42;
					break;
			};
		};
	});
	module.on("disable", function () {
		mc.timer.timerSpeed =1.0;
	});
});