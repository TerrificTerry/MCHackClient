/// api_version=2
var script = registerScript({
    name: "AAC5eVanillaFly",
    version: "1.0",
    authors: ["liulihaocai"]
});

var C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer')
var S40PacketDisconnect = Java.type('net.minecraft.network.play.server.S40PacketDisconnect')
var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils')
var AxisAlignedBB = Java.type('net.minecraft.util.AxisAlignedBB')

script.registerModule({
    name: "AAC5eVanillaFly",
    description: "Bypass AAC5",
    category: "Movement",
    settings: {
        speed: Setting.float({
            name: "FlySpeed",
            default: 3.5,
            min: 1.0,
            max: 5.0
        }),
        mode: Setting.list({
            name: "PacketMode",
            default: "FDP",
            values: ["FDP", "Rise"]
        })
    }
}, function(module) {
    var blockc03 = false
    var packets = []

    module.on("update", function() {
        mc.thePlayer.capabilities.isFlying = false;
    });

    module.on("packet", function(event) {
        var packet = event.getPacket()
        if (packet instanceof S40PacketDisconnect) {
            module.setState(false)
        } else if (blockc03 && packet instanceof C03PacketPlayer && !mc.theWorld.checkBlockCollision(new AxisAlignedBB(packet.x - 0, packet.y, packet.z - 0, packet.x + 0, packet.y + mc.thePlayer.height, packet.z + 0))) {
            packets.push(packet)
            event.cancelEvent()
            if (packets.length > 10) { // this can be changed
                sendC03();
            }
        }
    });

    module.on("enable", function() {
        blockc03 = true
    });

    module.on("disable", function() {
        blockc03 = false
        sendC03()
        mc.thePlayer.noClip = false;
        mc.thePlayer.motionX = 0;
        mc.thePlayer.motionY = 0;
        mc.thePlayer.motionZ = 0;
    });

    function sendC03() {
        blockc03 = false;
        var mode = module.settings.mode.get().toLowerCase()
        for (var i = 0; i < packets.length; i++) {
            var packet = packets[i]
            if (packet.isMoving()) {
                mc.getNetHandler().addToSendQueue(packet);
                if (mode == "fdp") {
                    mc.getNetHandler().addToSendQueue((new C03PacketPlayer.C04PacketPlayerPosition(packet.getPositionX(), 1.7976931348623157E+308, packet.getPositionZ(), true)));
                } else if (mode == "rise") {
                    mc.getNetHandler().addToSendQueue((new C03PacketPlayer.C04PacketPlayerPosition(packet.getPositionX(), -1e+159, packet.getPositionZ() + 10, true)));
                }
                mc.getNetHandler().addToSendQueue((new C03PacketPlayer.C04PacketPlayerPosition(packet.getPositionX(), packet.getPositionY(), packet.getPositionZ(), true)));
            }
        }
        packets = []
        blockc03 = true;
    }
})