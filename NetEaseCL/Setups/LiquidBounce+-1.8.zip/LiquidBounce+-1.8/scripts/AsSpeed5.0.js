var script = registerScript({
    name: "AsSpeed",
    version: "5.0",
    authors: ["As丶One"]
});
var Mode = Setting.list({
    name: "Mode",
    values: ["Custom", "OnGround", "Clip"],
    default: "Custom"
})
var speed = Setting.float({
    name: "Speed",
    default: 0.5,
    min: 0.15,
    max: 2.0
})
var OnGroundSpeed = Setting.float({
    name: "OnGroundSpeed",
    default: 0.5,
    min: 0.15,
    max: 2.0
})
var motionY = Setting.float({
    name: "MotionY",
    default: 0.42,
    min: 0.1,
    max: 2
})
var Timer = Setting.float({
    name: "Timer",
    default: 1.00,
    min: 0.1,
    max: 2
})
var Clip = Setting.integer({
    name: "Clip",
    default: 4,
    min: 1,
    max: 10
})
var Clipdelay = Setting.integer({
    name: "Clipdelay",
    default: 0,
    min: 0,
    max: 10
})
var LiquidBounce = Java.type("net.ccbluex.liquidbounce.LiquidBounce")
var MovementUtils = Java.type("net.ccbluex.liquidbounce.utils.MovementUtils")
var classProvider = LiquidBounce.INSTANCE.getWrapper().getClassProvider();
var KillAura = Java.type("net.ccbluex.liquidbounce.features.module.modules.combat.KillAura");
var KillAura = LiquidBounce.moduleManager.getModule(KillAura.class)
var packets = []
var Delay = 0
function move() {
   Delay++
   if(Mode.get() == "Clip" && Delay > Clipdelay.get()){
   hClip(Clip.get());
   Delay = 0
   }
   if(Mode.get() == "Clip" && MovementUtils.isMoving()){
    mc.thePlayer.motionY = 0.42
   }
   if(Mode.get() == "Custom"){
   mc.timer.timerSpeed = Timer.get()
    if(MovementUtils.isMoving()){
        MovementUtils.strafe(speed.get())
        mc.thePlayer.motionY = motionY.get()
    }
    return
    var dir = mc.thePlayer.rotationYaw / 180 * Math.PI
    if (mc.thePlayer.motionY < 0) mc.thePlayer.motionY = -0.05
    mc.thePlayer.motionX = -Math.sin(dir) * speed.get()
    mc.thePlayer.motionZ = Math.cos(dir) * speed.get()
   }
   //test Mode
    if(Mode.get() == "OnGround"){
   mc.timer.timerSpeed = Timer.get()
    if(MovementUtils.isMoving()){
        MovementUtils.strafe(OnGroundSpeed.get())
    }
    return
    var dir = mc.thePlayer.rotationYaw / 180 * Math.PI
    if (mc.thePlayer.motionY < 0) mc.thePlayer.motionY = -0.05
    mc.thePlayer.motionX = -Math.sin(dir) * OnGroundSpeed.get()
    mc.thePlayer.motionZ = Math.cos(dir) * OnGroundSpeed.get()
   }
}
script.registerModule({
    name: "AsSpeed",
    description: "AsSpeed By As丶One",
    category: "Fun",
    settings: {
		Mode: Mode,
        speed: speed,
		OnGroundSpeed: OnGroundSpeed,
		Timer: Timer,
		Clip: Clip,
		Clipdelay: Clipdelay,
        motionY: motionY
    }
},
 function (module) {
    var File = Java.type("java.io.File");
    var FileReader = Java.type("java.io.FileReader");
    var BufferedReader = Java.type("java.io.BufferedReader");
    var FileWriter = Java.type("java.io.FileWriter");
    var BufferedWriter = Java.type("java.io.BufferedWriter");
    var Timer = Java.type("java.util.Timer");
    var LiquidBounce = Java.type("net.ccbluex.liquidbounce.LiquidBounce")
    var classProvider = LiquidBounce.INSTANCE.getWrapper().getClassProvider();
    var FileManager = Java.type("net.ccbluex.liquidbounce.file.FileManager")
    var FileManager = LiquidBounce.fileManager
	var version = Java.type("net.ccbluex.liquidbounce.injection.backend.Backend").MINECRAFT_VERSION
    var sendPacket;
        if (version == "1.8.9") {
        sendPacket = function (packet) {
            try {
                imc.getNetHandler().addToSendQueue(packet)
            } catch (error) {
                mc.getNetHandler().addToSendQueue(packet)
            }
        }
    } else {
        sendPacket = function (packet) {
            try {
                mc.netHandler.networkManager.sendPacket(packet)
            } catch (error) {
                imc.getNetHandler().addToSendQueue(packet)
            }
        }
    }

    function readFile(filePath) {
        var file = new File(filePath);
        var reader = new BufferedReader(new FileReader(file));
        var content = "";
        var line;
        while ((line = reader.readLine()) !== null) content += line
        return content;
    }
    //chat.print(FileManager.hudConfig)
    //chat.print(Java.from(FileManager.class.getDeclaredFields()))
	//下面这一段里面填写你的图片全数据（在hud.json里面查看image部分)
    var image = "1"
    var hudConfig = eval(readFile(FileManager.hudConfig.getFile()))
    var flag = true
    for (var i in hudConfig) {
        if (hudConfig[i].Type == "Image" && hudConfig[i].Image == image) flag = false
    }
    //if (flag) return;   //这一段是保持return让此js失效
    var doAsFly = false
    var stage = 0
    var timer = 0
    module.on("enable", function () {
        y = mc.thePlayer.posY
        timer = 0
		Delay = 0
    });
    module.on("disable", function () {
    	mc.timer.timerSpeed = 1.0;
        packets.forEach(function () {
            mc.netHandler.networkManager.sendPacket(packets.shift())
        })
    });
    module.on("update", function () {
        if(!MovementUtils.isMoving())timer=0
        else timer++
        if (mc.thePlayer.onGround && timer>1) {
            doAsFly = true
            stage = 0
            move()
        }
        if (stage >= 1) {
            doAsFly = false
            packets.forEach(function () {
                sendPacket(packets.shift())
            })
        }
    });
    module.on("packet", function (event) {
        if (!doAsFly) return
        var packet = event.packet
        if (classProvider.isCPacketPlayerPosition(packet) || classProvider.isCPacketPlayerPosLook(packet) || classProvider.isCPacketPlayer(packet)) {
            event.cancelEvent()
            packets.push(packet)
            stage++
        }
    });
});
function hClip(d) {
	var playerYaw = Math.radians(mc.thePlayer.rotationYaw);
	mc.thePlayer.setPosition(mc.thePlayer.posX + d * -Math.sin(playerYaw), mc.thePlayer.posY, mc.thePlayer.posZ + d * Math.cos(playerYaw));
}
Math.radians = function(degrees) {
	return degrees * Math.PI / 180;
};