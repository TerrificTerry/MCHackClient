﻿var script = registerScript({
    name: "AIRLadder",
    version: "1.0",
    authors: ["As丶One"]
});
script.registerModule({
    name: "AIRLadder",
    description: "AIRLadder By As丶One",
    category: "Fun",
}, function (module) {
    module.on("update", function () {
        mc.thePlayer.isOnLadder()&&mc.gameSettings.keyBindJump.pressed&&(mc.thePlayer.motionY=0.09)
    });
});