﻿var scriptName = "NoFallcomfig";
var scriptVersion = 1.0;
var scriptAuthor = "暗狼";

var noFallModule = moduleManager.getModule("NoFall");

var autoNoFall = new AutoNoFall();
var client;

function AutoNoFall() {
    this.getName = function() {
        return "NoFallComfig";
    };

    this.getDescription = function() {
        return "NoFallComfig";
    };

    this.getCategory = function() {
        return "Fun";
    };

    this.onUpdate = function() {
		if (mc.thePlayer.fallDistance > 2.1)
			noFallModule.setState(true)//clem修改
		
		if (mc.thePlayer.onGround)
			noFallModule.setState(false)

		if (mc.thePlayer.fallDistance > 30)
			noFallModule.setState(false)//clem修改

		if (mc.thePlayer.onWater)
			noFallModule.setState(false)//clem修改
	}
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(autoNoFall);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}