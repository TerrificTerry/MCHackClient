//this js is from LiquidBounce Forums
//Made by CookieChinese Copy by Manager2021

var scriptName = "Velocity"
var scriptVersion = 2.0;
var scriptAuthor = "Cookie"

var AACVelocity = new AACVelocity();
var client;

var MovementUtils = Java.type("net.ccbluex.liquidbounce.utils.MovementUtils");
var MSTimer = Java.type("net.ccbluex.liquidbounce.utils.timer.MSTimer");

var MathHelper = Java.type("net.minecraft.util.MathHelper");

var C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer');
var C04PacketPlayerPosition = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition')
var C05PacketPlayerLook = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C05PacketPlayerLook');
var C06PacketPlayerPosLook = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C06PacketPlayerPosLook');

var S06PacketUpdateHealth = Java.type('net.minecraft.network.play.server.S06PacketUpdateHealth');
var S08PacketPlayerPosLook = Java.type("net.minecraft.network.play.server.S08PacketPlayerPosLook");
var S12PacketEntityVelocity = Java.type('net.minecraft.network.play.server.S12PacketEntityVelocity');
var S27PacketExplosion = Java.type('net.minecraft.network.play.server.S27PacketExplosion');

var timer = new MSTimer();

function AACVelocity() {
	
	var settings = {
		//By-mumy
		Mode: value.createList("Mode", ["AAC4", "AAC5", "Jump", "Glitch", "Custom"], "AAC5"),
		CustomPushXZ: value.createInteger("CustomPushXZ", 50, 1, 100),
		TimePassed: value.createInteger("TimePassed", 80, 1, 100),
		GlitchY: value.createInteger("GlitchY", 0.42, 0.01, 1),
		GlitchNoMove:  value.createBoolean("GlitchNoMove", true)
	};
	
	var var0 = false;//hurt
	var var1 = false;//gotVelocity

    this.getName = function() {
        return "CookieVelocity";
    }

    this.getTag = function() {
        return settings.Mode.get();
    }

    this.getDescription = function() {
        return ":/";
    }

    this.getCategory = function() {
        return "Combat";
    }

    this.onEnable = function() {
		
	}

    this.onUpdate = function() {
		switch (settings.Mode.get()) {
			case "AAC5":
				if (mc.thePlayer.hurtTime <= 0) {
					return;
				} if (mc.thePlayer.onGround) {
					if (mc.thePlayer.hurtTime <= 6) {
						mc.thePlayer.motionX *= 0.600151164;
						mc.thePlayer.motionZ *= 0.600151164;
					} if (mc.thePlayer.hurtTime <= 4) {
						mc.thePlayer.motionX *= 0.800151164;
						mc.thePlayer.motionZ *= 0.800151164;
					}
				} else if ( mc.thePlayer.hurtTime <= 9) {
					mc.thePlayer.motionX *= 0.8001421204;
					mc.thePlayer.motionZ *= 0.8001421204;
				}
				break;
			case "AAC4":
				if (!mc.thePlayer.onGround) {
					if (mc.thePlayer.hurtTime != 0 && var0) {
						mc.thePlayer.motionX *= 0.6;
						mc.thePlayer.motionZ *= 0.6;
					}
				} else if (timer.hasTimePassed(80)) {
					var0 = false;
				}
				break;
			case "Custom":
				if (mc.thePlayer.onGround && mc.thePlayer.hurtTime <= 8 && var0) {
					mc.thePlayer.motionX *= settings.CustomPushXZ.get();
					mc.thePlayer.motionZ *= settings.CustomPushXZ.get();
				}
				break;
			case "Glitch":
				mc.thePlayer.noClip = var1;
				if (mc.thePlayer.onGround) {
					if (mc.thePlayer.hurtTime = 7) {
						if (settings.GlitchNoMove.get()) {
							
						}
						mc.thePlayer.motionY = 0.4;
						var1 = false;
					}
				}
				break;
			default:
				var f = mc.thePlayer.rotationYaw * 0.017453292;
				if (mc.thePlayer.onGround) {
					if (mc.thePlayer.hurtTime > 0){
						mc.thePlayer.motionY = 0.42;
						if (var0) {
							mc.thePlayer.motionX -= Math.sin(f) * 0.2;
							mc.thePlayer.motionZ += Math.cos(f) * 0.2;
						}
					}
				} else if (timer.hasTimePassed(settings.TimePassed.get())) {
					var0 = false;
				}
				break;
		}
	}
	
	this.onPacket = function(event) {
		var packet = event.getPacket();
		if (packet instanceof S12PacketEntityVelocity && mc.thePlayer != null && mc.theWorld.getEntityByID(packet.getEntityID()).getEntityId() == mc.thePlayer.getEntityId()) {
			switch (settings.Mode.get()) {
				case "AAC4":
					timer.reset();
					var0 = true;
					break;
				case "Glitch":
					if (mc.thePlayer.onGround) {
						var1 = true;                    
						event.cancelEvent();
					}
					break;
			}
			return;
		} if (packet instanceof S06PacketUpdateHealth) {
			event.cancelEvent();
			return;
		} if (packet instanceof S27PacketExplosion) {
			event.cancelEvent();
		}
	}
	
	this.addValues = function(values) {
        for (var list = Object.keys(settings), v = list.length; v != 0;) {
			values.add(settings[list[list.length - v--]]);
		}
    }
}

function onEnable() {
    client = moduleManager.registerModule(AACVelocity);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}


