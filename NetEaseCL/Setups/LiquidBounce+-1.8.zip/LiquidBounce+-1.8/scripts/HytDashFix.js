var scriptName = "HytDash";
var scriptVersion = 1.0;
var scriptAuthor = "AquaVit" //fu917 fixed
var BlinkModule = moduleManager.getModule("Blink");
var HytLongJump = new HytLongJump();
var client;

function HytLongJump() {
	var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils')
	var ArrayList = Java.type('java.util.ArrayList');
	var LinkedList = Java.type('java.util.LinkedList');
    this.getName = function() {
        return "HytLongJumpFIX";
    };

    this.getDescription = function() {
        return "HytLongJumpFIX";
    };

    this.getCategory = function() {
        return "Fun";
    };
    this.onEnable = function() {
		BlinkModule.setState(true);
		mc.thePlayer.sendQueue.addToSendQueue(new LinkedList(mc.thePlayer.posX, mc.thePlayer.getEntityBoundingBox().minY + (mc.thePlayer.getEyeHeight() / 2)));
		mc.thePlayer.sendQueue.addToSendQueue(new LinkedList(mc.thePlayer.posX, mc.thePlayer.getEntityBoundingBox().minY, mc.thePlayer.posZ));		    
    }
    this.onUpdate = function() {
		mc.thePlayer.sendQueue.addToSendQueue(new LinkedList(mc.thePlayer.posX, mc.thePlayer.getEntityBoundingBox().minY, mc.thePlayer.posZ));
	}
    this.onDisable = function () {
		mc.timer.timerSpeed = 1.0;
		if(mc.thePlayer == null)
            return;
		BlinkModule.setState(false);
    }
    this.onMotion = function () {
        if(MovementUtils.isMoving()) {
            mc.timer.timerSpeed = 1.0;

            if(mc.thePlayer.onGround) {
                MovementUtils.strafe(8.0);
                mc.thePlayer.motionY = 0.42;
            }
            MovementUtils.strafe(8.0);
        } else {
            mc.thePlayer.motionX = mc.thePlayer.motionZ = 0;
        }
    }
	this.onPacket = function(event) {
	var packet = event.getPacket();
    if(mc.thePlayer == null)
        return;	
    if (packet instanceof C03PacketPlayer) {
        
	    }
    if (packet instanceof C03PacketPlayer.C04PacketPlayerPosition || packet instanceof C03PacketPlayer.C06PacketPlayerPosLook || packet instanceof C08PacketPlayerBlockPlacement || packet instanceof C0APacketAnimation || packet instanceof C0BPacketEntityAction || packet instanceof C02PacketUseEntity) {
        
		mc.thePlayer.sendQueue.addToSendQueue(new ArrayList());
	    }
	}
}
function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(HytLongJump);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}