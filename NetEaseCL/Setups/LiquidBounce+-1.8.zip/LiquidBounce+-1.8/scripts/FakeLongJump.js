var scriptName = "FakeLongJump";
var scriptAuthor = "FunkNight";
var scriptVersion = 1.0;

var S08PacketPlayerPosLook = Java.type('net.minecraft.network.play.server.S08PacketPlayerPosLook');
var C06PlayerPacket = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C05PacketPlayerLook');
var C06PlayerPacket = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C06PacketPlayerPosLook');
var C04 = Java.type("net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition");
var C05PacketPlayerLook = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C05PacketPlayerLook');
var C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer');
var S08PacketPlayerPosLook = Java.type("net.minecraft.network.play.server.S08PacketPlayerPosLook");
var air = false;
var Mx;
var Mz;
var My;
function FakeLongJumpModule() {
	var Mode = value.createList("Mode", ["AAC5","MineMora"], "AAC5");
	var AutoDisable = value.createBoolean("AutoDisable", true);
	
    this.getName = function() {
        return "FakeLongJump";
    }

    this.getDescription = function() {
        return "Longjump";
    }

    this.getCategory = function() {
        return "Movement";
    }
   this.getTag = function() {
        return Mode.get() + '';
   }

    this.onEnable = function() {
		if(mc.thePlayer.onGround){
			mc.thePlayer.jump();
			air = false
		}
		if(Mode.get() == "MineMora"){
			moduleManager.getModule("Blink").setState(true);
			mc.timer.timerSpeed = 0.2;
		}
    }
	this.onPacket = function (event) {
		var packet = event.getPacket();
		if (packet instanceof S08PacketPlayerPosLook) {
			moduleManager.getModule("FakeLongJump").setState(false);
		}    
	}
    this.onUpdate = function() {
		if (!mc.thePlayer.onGround) {
			air++;
		} else if (air > 3 && AutoDisable.get()) {
			moduleManager.getModule("FakeLongJump").setState(false);
			Mx = mc.thePlayer.posX;
			Mz = mc.thePlayer.posZ;
			My = mc.thePlayer.posY;
		}
		switch (Mode.get()) {
			case "AAC5":
				mc.thePlayer.jumpMovementFactor = 0.05649;
				mc.thePlayer.motionY += 0.014;
			break;
			case "MineMora":
				mc.thePlayer.jumpMovementFactor = 0.45145;
				mc.thePlayer.motionY += 0.04;
			break;
		}
    }
	this.addValues = function(values) {
		values.add(AutoDisable);
		values.add(Mode);
	}

    this.onDisable = function() {
		moduleManager.getModule("Blink").setState(false);
        mc.timer.timerSpeed = 1;
    }
}

var FakeLongJumpModule = new FakeLongJumpModule();
var FakeLongJumpModuleClient;

function onEnable() {
    FakeLongJumpModuleClient = moduleManager.registerModule(FakeLongJumpModule);
}

function onDisable() {
    moduleManager.unregisterModule(FakeLongJumpModuleClient);
}