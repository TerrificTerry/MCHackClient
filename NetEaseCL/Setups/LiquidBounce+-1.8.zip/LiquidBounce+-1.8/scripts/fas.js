var scriptName = "fasfasfas"; // The name of your script
var scriptVersion = 1.0; // The version of your script
var scriptAuthor = "CCBlueX"; // The author of your script (eg. your username)

var exampleModule = new ExampleModule();
var exampleModuleClient;

function ExampleModule() {
    this.getName = function() {
        return "SuperOPVelocity";
    };

    this.getDescription = function() {
        return "Best velocity";
    };

    this.getCategory = function() {
        return "Misc";
    };

    this.onUpdate = function() {
        if(mc.thePlayer.hurtTime >=0)
        chat.print("You just take 0 knockback")
        }
    }
}

function onLoad() {
    // Currently this event has to be in every script even if it is not directly needed.
};

function onEnable() {
    exampleModuleClient = moduleManager.registerModule(exampleModule);
};

function onDisable() {
    moduleManager.unregisterModule(exampleModuleClient);
};

