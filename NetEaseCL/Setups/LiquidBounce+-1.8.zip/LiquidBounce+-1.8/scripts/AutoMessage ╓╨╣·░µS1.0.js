var scriptName = "AutoMessage"; 
var scriptVersion = 7.0
var scriptAuthor = "soulplexis,reset by cookie";

var mobs = Java.type("net.minecraft.entity.EntityCreature");
var players = Java.type("net.minecraft.entity.player.EntityPlayer");
var S02PacketChat = Java.type('net.minecraft.network.play.server.S02PacketChat')
var scaffoldModule = moduleManager.getModule("Scaffold");
var Fly = moduleManager.getModule("Fly");
var Killaura = moduleManager.getModule("Killaura");
var Speed = moduleManager.getModule("Speed");
var Color = Java.type('java.awt.Color')
var Fonts = Java.type("net.ccbluex.liquidbounce.ui.font.Fonts");
script.import('lib/glFunctions.js');
script.import("lib/systemFunctions.js")
script.import('lib/timingFunctions.js');
var ScaledResolution = Java.type("net.minecraft.client.gui.ScaledResolution")


var RenderUtils = Java.type('net.ccbluex.liquidbounce.utils.render.RenderUtils')

var autoMessage = new autoMessage();
var autoMessageClient;
	
function autoMessage() {
	var ticks = 0;
	var a = false;
	var b = 0;
	var c = 0;
	var d = 0;
	var Mode = value.createList("Mode", ["Before", "After",], "Before");
	var AutoL = value.createBoolean("AutoL", true);
	var Mob = value.createBoolean("Mob", false);
	var Player = value.createBoolean("Player", true);
	var Instant = value.createBoolean("Instant", false);
	var GG = value.createBoolean("GG", true);
	var Wdr = value.createBoolean("Wdr", true);
	var Message = value.createText("Message", "L");
	var WdrMessage = value.createText("WdrMessage", "Killaura");
	var Wdrtext = value.createText("Wdrtext", "/wdr");
	var Lname = value.createText("Lname", "曲奇");
	var GGname = value.createText("GGname", "曲奇");
	var GGNameT = value.createBoolean("GGNameT", true);
	var StartSpammer = value.createBoolean("StartSpammer", true);
	var AutoRejoin = value.createBoolean("AutoRejoin", true);
	var AutoPlay = value.createBoolean("AutoPlay", true);
	var CheckPlayer = value.createText("CheckPlayer", ":");
	var AutoPlayTick = value.createInteger("AutoPlayTick", 80, 5, 100);
	var RejoinTick = value.createInteger("RejoinTick", 40, 5, 100);
	var AutoDisableTick = value.createInteger("AutoDisableTick", 80, 5, 100);
	var AutoLName = value.createBoolean("AutoLName", true);
	var nameBefore = value.createText("nameBefore", "[");
	var nameAfter = value.createText("nameAfter", "]");
	var GGandKillCheck = value.createText("GGandKillCheck", "胜利");
	var AutoPlayCheck = value.createText("AutoPlayCheck", "胜利");
	var AutoRejoinCheck1 = value.createText("AutoRejoinCheck1", "继续");
	var AutoRejoinCheck2 = value.createText("AutoRejoinCheck2", "提出");
	var GGText = value.createText("GGText", "GG");
	var StartSpammerChecks = value.createText("StartSpammerChecks", "开始");
	var Autodisable = value.createBoolean("Autodisable", true);
	var AutodisableChecks1 = value.createText("AutodisableChecks1", "胜利");
	var AutodisableChecks2 = value.createText("AutodisableChecks2", "死亡");
	var AutodisableKillaura = value.createBoolean("Killaura", true);
	var AutodisableSpeed = value.createBoolean("Speed", true);
	var AutodisableFly = value.createBoolean("Fly", true);
	var AutodisableScaffold = value.createBoolean("Scaffold", true);
	var AutoRejoinText = value.createText("AutoRejoinText", "/rejoin");
	var HypixelAutoPlayMode = value.createList("HypixelAutoPlayMode", ["BedWars_1v1","BedWars_2v2","BedWars_3v3","BedWars_4v4","SkyWars_Solo","SkyWars_Solo_Insane","SkyWars_Solo_LuckyBlock","SkyWars_Team","SkyWars_Team_Insane","SkyWars_Team_LuckyBlock","SurivialGames_Solo","SurivialGames_Team","MiniWalls",], "SkyWars_Solo");
	var GGAfterText = value.createText("GGAfterText", "Pls use Cookie Config");
	var StartSpammerText = value.createText("StartSpammerText", "Pls use Liquidbounce Config");
	var AutoRegister = value.createBoolean("AutoRegister", true);
	var AutoLogin = value.createBoolean("AutoLogin", true);
	var AutoRegisterDouble = value.createBoolean("AutoRegisterDouble", true);
	var AutoRegisterCheck = value.createText("AutoRegisterCheck", "注册");
	var AutoRegisterCommand = value.createText("AutoRegisterCommand", "/");
	var AutoRegisterCommandText = value.createText("AutoRegisterCommandText", "register");
	var AutoRegisterPrefixCheck = value.createText("AutoRegisterPrefixCheck", ".");
	var AutoRegisterText = value.createText("AutoRegisterText", "123456789a");
	var AutoLoginCheck = value.createText("AutoLoginCheck", "登录");
	var AutoLoginCommand = value.createText("AutoLoginCommand", "/");
	var AutoLoginCommandText = value.createText("AutoLoginCommandText", "login");
	var AutoLoginText = value.createText("AutoLoginText", "123456789a");
	var AutoLoginPrefixCheck = value.createText("AutoLoginPrefixCheck", ".");
	var Killcount = value.createBoolean("Killcount", true);
	var KillcountY = value.createInteger("KillcountY", 80, 1, getScaledWidth());
	var KillcountX = value.createInteger("KillcountX", 40, 5, getScaledHeight());
	var KillcountClear = value.createBoolean("KillcountClear", true);
	var KillClearDelay = value.createInteger("KillClearDelay", 80, 5, 100);
	this.getName = function() {
        return "AutoMessage";
    };

    this.getDescription = function() {
        return "Mentions the target with a message when you kill them.";
    };

    this.getCategory = function() {
        return "Fun";
    };
	this.onEnable = function() {
		target = null;
		a == false;
		b = 0;
		c = 0;
		d = 0;
		}
		this.onPacket = function(event) {
        var packet = event.getPacket();
		if(packet instanceof S02PacketChat) {		
			if(GG.get() == true) {
        	if (packet.getChatComponent().getUnformattedText().contains(GGandKillCheck.get())) {
				if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {
				if(GGNameT.get() == true){
				mc.thePlayer.sendChatMessage(nameBefore.get() + GGname.get() + nameAfter.get() + " " + GGText.get() + " " + GGAfterText.get())
				}else{
				mc.thePlayer.sendChatMessage(GGText.get())
				}
				}
			}
		  }
		 if(Killcount.get() == true) {
        	if (packet.getChatComponent().getUnformattedText().contains(GGandKillCheck.get())) {
				if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {
				setTimeout(function() {				
				c = 0
				}, KillClearDelay.get() * 50)
            
				}
			}
		  }
		  		  	if(AutoRegister.get() == true) {
        	if (packet.getChatComponent().getUnformattedText().contains(AutoRegisterCheck.get())) {
				if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {
				if(AutoRegisterDouble.get() == true){
				mc.thePlayer.sendChatMessage(AutoRegisterCommand.get() + AutoRegisterCommandText.get() + " " + AutoRegisterText.get() + " " + AutoRegisterText.get())
				}else{
				mc.thePlayer.sendChatMessage( AutoRegisterCommand.get() + AutoRegisterCommandText.get() + " " + AutoRegisterText.get())
				}
				}
			}
		  }
		    if(AutoLogin.get() == true) {
        	if (packet.getChatComponent().getUnformattedText().contains(AutoLoginCheck.get())) {
				if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {
				mc.thePlayer.sendChatMessage(AutoLoginCommand.get() + AutoLoginCommandText.get() + " " + AutoLoginText.get())
				}
				}
		  }
		  if(AutoRejoin.get() == true){
			if (packet.getChatComponent().getUnformattedText().contains(AutoRejoinCheck1.get())) {
			if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {
               setTimeout(function() {				
				mc.thePlayer.sendChatMessage(AutoRejoinText.get())
				}, RejoinTick.get() * 50)
			                      }
								}	
			if (packet.getChatComponent().getUnformattedText().contains(AutoRejoinCheck2.get())) {
			if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {		 
			   setTimeout(function() {				
				mc.thePlayer.sendChatMessage(AutoRejoinText.get())
				}, RejoinTick.get() * 50)
			         }
				}  
		  }
		  if(Autodisable.get() == true){
			if (packet.getChatComponent().getUnformattedText().contains(AutodisableChecks1.get())) {
			if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {
			setTimeout(function() {
             if(AutodisableKillaura.get() == true){
				Killaura.setState(false)
			 }
             if(AutodisableScaffold.get() == true){
				scaffoldModule.setState(false)
			 }
             if(AutodisableFly.get() == true){
				Fly.setState(false)
			 }
             if(AutodisableSpeed.get() == true){
				Speed.setState(false)
			 }
             }, AutoDisableTick.get() * 50)			 
			                      }
								}
		  								
			if (packet.getChatComponent().getUnformattedText().contains(AutodisableChecks2.get())) {
			if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {
            setTimeout(function() {				
             if(AutodisableKillaura.get() == true){
				Killaura.setState(false)
			 }
             if(AutodisableScaffold.get() == true){
				scaffoldModule.setState(false)
			 }
             if(AutodisableFly.get() == true){
				Fly.setState(false)
			 }
             if(AutodisableSpeed.get() == true){
				Speed.setState(false)
			 }
             }, AutoDisableTick.get() * 50)					 
			         }
				}  
		  }
		  if(StartSpammer.get() == true) {
        	if (packet.getChatComponent().getUnformattedText().contains(StartSpammerChecks.get())) {
            if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {
				mc.thePlayer.sendChatMessage(nameBefore.get() + GGname.get() + nameAfter.get() + " " + StartSpammerText.get())
				}
				}
			}
			if(AutoPlay.get() == true) {
        	if (packet.getChatComponent().getUnformattedText().contains(AutoPlayCheck.get())) {
			if (!packet.getChatComponent().getUnformattedText().contains(CheckPlayer.get())) {	
		a = true;
	   switch(HypixelAutoPlayMode.get()) {
	   case"BedWars_1v1":
	   setTimeout(function() {
	   	   mc.thePlayer.sendChatMessage("/play bedwars_eight_one");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"BedWars_2v2":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play bedwars_eight_two");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"BedWars_3v3":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play bedwars_four_three");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"BedWars_4v4":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play bedwars_four_four");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"SkyWars_Solo":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play solo_normal");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"SkyWars_Solo_Insane":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play solo_insane");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"SkyWars_Solo_LuckyBlock":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play solo_insane_lucky");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"SkyWars_Team":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play teams_normal");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"SkyWars_Team_Insane":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play teams_insane");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"SkyWars_Team_LuckyBlock":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play teams_insane_lucky");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"SurivialGames_Solo":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play blitz_solo_normal");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"SurivialGames_Team":
	   setTimeout(function() {
	   mc.thePlayer.sendChatMessage("/play blitz_teams_normal");
	   }, AutoPlayTick.get() * 50)
	   break;
	   case"MiniWalls":
	   setTimeout(function() { 
	   mc.thePlayer.sendChatMessage("/play arcade_mini_walls");
	   }, AutoPlayTick.get() * 50)
	   break;	
				}
			    }
				}
				
			}
		  }
		}
	
    this.onMotion = function () {
	if(target != null && (((target instanceof mobs && Mob.get() == true) || Mob.get() == false && !(target instanceof mobs)) || ((target instanceof players && Player.get() == true) || Player.get() == false && !(target instanceof players))) && ((Instant.get() == true && target.getHealth() == 0) || Instant.get() == false && target.isDead == true)) {
		switch(Mode.get()) {
			case "After":
			c = c + 1
			if(Wdr.get() == true) {
			mc.thePlayer.sendChatMessage(Wdrtext.get() + " " + target.getName() + " " + WdrMessage.get());
			}
			if(AutoL.get() == true){
			if(AutoLName.get() == true){
			mc.thePlayer.sendChatMessage(nameBefore.get() + Lname.get() + nameAfter.get() + target.getName() + " " + Message.get());
			}else{
			mc.thePlayer.sendChatMessage(target.getName() + " " + Message.get());
			}
			}
			break;
			case "Before":
			c = c + 1
			if(AutoL.get() == true){
			if(AutoLName.get() == true){
			mc.thePlayer.sendChatMessage(nameBefore.get() + Lname.get() + nameAfter.get() + " " + Message.get()+ " " + target.getName());
			}else{
			mc.thePlayer.sendChatMessage(target.getName() + " " + Message.get());
			}
			}
			if(Wdr.get() == true) {
			mc.thePlayer.sendChatMessage(Wdrtext.get() + " "  + target.getName() + " " + WdrMessage.get());
			}
			break;
		}
		target = null;
	}
	}
	this.onDisable = function() {
	}
	    this.onUpdate = function() {
	    if (a == true) {
			ticks++;
		}
		if (ticks != 0 && ticks < AutoPlayTick.get()) {
			if (b != 7) {
				b++;
			}
		
		}
		if (ticks > AutoPlayTick.get()) {
			ticks = 0;
			a = false;
			b = 0;
		}
	}
		this.onRender2D = function () {
		mc.fontRendererObj.drawStringWithShadow("You Killed:" + c, KillcountX.get(), KillcountY.get(), 10395294);
        var mcWidth = getScaledWidth();
        //RenderUtils.drawBorderedRect(mcWidth / 2 - 92 , 3, mcWidth / 2 + 92, 23, 3, new Color(0, 0, 0, 150).getRGB(), new Color(0, 0, 0, 150).getRGB());
		if (a == true) {
	        RenderUtils.drawBorderedRect(mcWidth / 2 - 92, b, mcWidth / 2 + 92, b + 25, 3, new Color(255, 255, 255, 90).getRGB(), new Color(255, 255, 255, 90).getRGB());
            Fonts.font40.drawCenteredString("Auto  Play&Disable", mcWidth / 2 + 3, b + 5, 0xffffff);
            Fonts.font35.drawCenteredString("next game in " + (4 - parseInt(ticks / 20)) + 's', mcWidth / 2 + 3, b + 16, 0xffffff);			
		}
    }
	this.addValues = function(values) {
		values.add(Mode);
		values.add(Mob);
		values.add(Player);
		values.add(Instant);
		values.add(Message);
		values.add(GG);
		values.add(Wdr);
		values.add(WdrMessage);
		values.add(Wdrtext);
		values.add(Lname);
		values.add(GGname);
		values.add(GGNameT);
		values.add(StartSpammer);
		values.add(AutoRejoin);
		values.add(AutoPlay);
		values.add(HypixelAutoPlayMode);
		values.add(GGAfterText);
		values.add(AutoL);
		values.add(CheckPlayer);
		values.add(AutoPlayTick);
		values.add(AutoDisableTick);
		values.add(AutoLName);
		values.add(RejoinTick);
		values.add(nameAfter);
		values.add(nameBefore);
		values.add(GGandKillCheck);
		values.add(AutoPlayCheck);
		values.add(AutoRejoinCheck1);
		values.add(AutoRejoinCheck2);
		values.add(GGText);
		values.add(StartSpammerChecks);
		values.add(Autodisable);
		values.add(AutodisableChecks1);
		values.add(AutodisableChecks2);
		values.add(AutodisableFly);
		values.add(AutodisableKillaura);
		values.add(AutodisableScaffold);
		values.add(AutodisableSpeed);
		values.add(AutoRejoinText);
		values.add(StartSpammerText);
		values.add(AutoRegister);
		values.add(AutoRegisterCommand);
		values.add(AutoRegisterCommandText);
		values.add(AutoRegisterDouble);
		values.add(AutoRegisterText);
		values.add(AutoRegisterCheck);
		values.add(AutoLogin);
		values.add(AutoLoginCheck);
		values.add(AutoLoginCommand);
		values.add(AutoLoginCommandText);
		values.add(AutoLoginText);
		values.add(AutoLoginPrefixCheck);
		values.add(AutoRegisterPrefixCheck);
		values.add(Killcount);
		values.add(KillcountX);
		values.add(KillcountY);
		values.add(KillcountClear);
		values.add(KillClearDelay);
    }
	var target;
	var EntityUtils = Java.type("net.ccbluex.liquidbounce.utils.EntityUtils")
	this.onAttack = function (event) {
		if (EntityUtils.isSelected(event.getTargetEntity(), true)) target = event.getTargetEntity();
	}
  }

function onLoad() {
};

function onEnable() {
    autoMessageClient = moduleManager.registerModule(autoMessage);
};

function onDisable() {
    moduleManager.unregisterModule(autoMessageClient);
};