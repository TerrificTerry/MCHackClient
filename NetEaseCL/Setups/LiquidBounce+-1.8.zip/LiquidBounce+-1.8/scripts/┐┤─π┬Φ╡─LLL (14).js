var C16PacketClientStatus = Java.type('net.minecraft.network.play.client.C16PacketClientStatus'),
    GuiChat = Java.type('net.minecraft.client.gui.GuiChat'),
    Keyboard = Java.type('org.lwjgl.input.Keyboard');
var keys = [
    mc.gameSettings.keyBindRight,
    mc.gameSettings.keyBindLeft,
    mc.gameSettings.keyBindBack,
    mc.gameSettings.keyBindForward,
    mc.gameSettings.keyBindJump,
    mc.gameSettings.keyBindSprint
];
var script = registerScript({
    name: 'Gui Move',
    version: '1.0.0',
    authors: ['Shurpe']
});
script.registerModule({
    name: 'GuiMove',
    description: '',
    category: 'Fun',
    settings: {
        mode: Setting.list({
            name: 'Mode',
            default: 'Normal',
			values: ['Normal', 'Bypass']
        })
    }
}, function (module) {
    module.on('update', function () {
        module.tag = module.settings.mode.get();
        if (!(mc.currentScreen instanceof GuiChat || mc.currentScreen == null)) {
            for (key in keys) {
                keyCode = keys[key].getKeyCode();
                keys[key].pressed = Keyboard.isKeyDown(keyCode);
            }
            if (Keyboard.isKeyDown(Keyboard.KEY_UP)) {
                if (mc.thePlayer.rotationPitch > -90) {
                    mc.thePlayer.rotationPitch -= 5;
                }
            }
            if (Keyboard.isKeyDown(Keyboard.KEY_DOWN)) {
                if (mc.thePlayer.rotationPitch < 90) {
                    mc.thePlayer.rotationPitch += 5;
                }
            }
            if (Keyboard.isKeyDown(Keyboard.KEY_LEFT)) {
                mc.thePlayer.rotationYaw -= 5;
            }
            if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT)) {
                mc.thePlayer.rotationYaw += 5;
            }
        }
    });
    module.on('packet', function(e) {
        var packet = e.getPacket();
        if (module.settings.mode.get() == 'Bypass') {
            if (packet instanceof C16PacketClientStatus && packet.getStatus() == C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT) {
                e.cancelEvent();
            }
        }
    });
});