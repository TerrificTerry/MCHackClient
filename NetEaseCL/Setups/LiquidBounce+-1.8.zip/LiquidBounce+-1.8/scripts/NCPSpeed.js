/// api_version=2
var script = registerScript({
    name: "Ababababds",
    version: "1.1",
    authors: ["Co丶Dynamic"]
});
var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils');
var RandomUtils=Java.type('net.ccbluex.liquidbounce.utils.misc.RandomUtils');
var S12PacketEntityVelocity = Java.type('net.minecraft.network.play.server.S12PacketEntityVelocity');
var Switcher;
script.registerModule({
    name: "NCPSpeed",
    description: "Co丶Dynamic",
    category: "Movement",
    settings: {
	}
}, function (module) {
	module.on("enable", function () {
	});
	module.on("update", function () {
		if(!(mc.thePlayer.isInWater() || mc.thePlayer.isInLava() || mc.thePlayer.isOnLadder() || mc.thePlayer.isRiding() || mc.thePlayer.isInWeb) && !mc.thePlayer.onGround) {
			if(mc.thePlayer.motionY>0) {
				mc.thePlayer.motionY = mc.thePlayer.motionY/0.9800000190734863;
				mc.thePlayer.jumpMovementFactor=0.0245;
				mc.thePlayer.motionY += 0.08;
				mc.thePlayer.motionY -= 0.0828;
				mc.thePlayer.motionY *= 0.9800000190734863;
				mc.timer.timerSpeed = 1.25;
			}else{
				mc.thePlayer.jumpMovementFactor=0.0285;
				mc.thePlayer.motionY = mc.thePlayer.motionY/0.9800000190734863;
				mc.thePlayer.motionY += 0.08;
				mc.thePlayer.motionY -= 0.0838;
				mc.thePlayer.motionY *= 0.9800000190734863;
				mc.timer.timerSpeed = 1.00;
			};
		}else{
			mc.timer.timerSpeed = 1.00;
		};
		if(mc.thePlayer.fallDistance>0.5 && mc.thePlayer.fallDistance<1.5) {
			mc.thePlayer.motionY = -1;
			mc.timer.timerSpeed = 1.5;
			mc.thePlayer.jumpMovementFactor=0.0285;
		};
		MovementUtils.strafe();
		if(mc.thePlayer.onGround) mc.timer.timerSpeed =1.0;
		if(mc.thePlayer.onGround && MovementUtils.isMoving()) {
			mc.thePlayer.jump();
			mc.timer.timerSpeed =1.0;
			mc.thePlayer.motionY = 0.419973;
			MovementUtils.strafe(0.485);
		};
	});
	module.on("disable", function () {
		mc.timer.timerSpeed =1.0;
	});
});