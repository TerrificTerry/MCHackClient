var scriptName = "HYTCriticals";
var scriptVersion = 1.0;
var scriptAuthor = "FunkNight";

var EntityPlayer = Java.type('net.minecraft.entity.player.EntityPlayer');
var EntityLivingBase = Java.type('net.minecraft.entity.EntityLivingBase');
var HYTCriticalsModule = new HYTCriticalsModule();
var client;
var delay = -1;

function HYTCriticalsModule() {

	var Mode = value.createList("Mode", ["Jump", "LowHop", "Render"], "Jump");
		
    this.getName = function () {
        return "4v4Criticals";
    };

    this.getTag = function () {
        return Mode.get() + '';
    };

    this.getDescription = function () {
        return "HYTCriticals";
    };

    this.getCategory = function () {
        return "Fun";
    };

    this.onAttack = function (event) {
        if (event.getTargetEntity() instanceof EntityPlayer) {
            entity = event.getTargetEntity();
        };
		switch (Mode.get()) {
			case "Jump":
				if(mc.thePlayer.onGround || isOnGround(0.5)){
					mc.thePlayer.jump();
				}
			break;
			case "LowHop":
				delay++;
				if(mc.thePlayer.onGround || isOnGround(0.5)){
					if(delay > 50){
						mc.thePlayer.motionY = 0.06;
					}
				}
			break;
			case "Render":
				mc.thePlayer.onCriticalHit(entity);
			break;
		};
    }
	this.addValues = function(values) {
	    values.add(Mode);
	}
}
function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(HYTCriticalsModule);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}