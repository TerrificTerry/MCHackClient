var scriptName = "HytCriticals";
var scriptAuthor = "HytCriticals";
var scriptVersion = 1.0;

function VulCanCriticalsModule() {
    this.getName = function () {
        return "HytCriticals2";
    }
    this.getCategory = function () {
        return "Misc";
    }
    this.getDescription = function () {
        return "HytCriticals2";
    }

    this.getTag = function() {
    return "AAC5";
    }

    this.onAttack = function (event) {
    mc.thePlayer.motionY = 0.04
}

    }
var vulCancriticalsModule = new VulCanCriticalsModule();
var vulCancriticalsModuleClient;

function onEnable() {
    disablerModuleClient = moduleManager.registerModule(vulCancriticalsModule);
}

function onDisable() {
    moduleManager.unregisterModule(vulCancriticalsModuleClient);
}