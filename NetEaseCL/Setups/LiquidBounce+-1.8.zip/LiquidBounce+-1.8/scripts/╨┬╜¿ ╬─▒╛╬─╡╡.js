var scriptName = "WolrdTime";
var scriptVersion = 1.0;
var scriptAuthor = "神帝"
var WolrdTime = new WolrdTime();
var client;

script.import('lib/minecraftUtils.js');
script.import('lib/timingFunctions.js');
script.import('lib/glFunctions.js');
script.import('lib/systemFunctions.js');

function WolrdTime() {
	var time = value.createFloat("Time", 13000, 0, 24000);
	
    this.getName = function() {
        return "WolrdTime";
    };
    this.getDescription = function() {
        return "WolrdTime";
    };
    this.getCategory = function() {
        return "Fun";
    };
    this.onEnable = function() {
		
    };
    this.onDisable = function() {

    };
	this.addValues = function(values) {
		values.add(time);
    };
	this.onPacket = function(event) {
	var packet = event.getPacket();
        if (packet instanceof net.minecraft.network.play.server.S03PacketTimeUpdate) {
							event.cancelEvent();
		}
	}
		this.onUpdate = function() {
								        mc.theWorld.setWorldTime((time.get()).intValue())
		}
}

function onLoad() {}

function onEnable() {
   WolrdTimeClient = moduleManager.registerModule(WolrdTime)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}